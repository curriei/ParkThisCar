/**
 * @author ibrahimmalik
 * @version 1.0
 */

package com.model;
import java.util.*;


public class parkModule {
/* 
 * The controller will use this module. It will pass the values of the inputs into 
 * the methods in this module. The goal of this module is to independetly take inputs and convert
 * them into a list of spots. This list will be used by the controller which will then pass it along to the 
 * result page.
 * 
 * List spots = new ArrayList();
 * 
 * Processing of inputs to produces viable spots
 * 
 * return spots;
 * 
 * results - OUTPUT sent back on RequestObject to controller
 */
}
