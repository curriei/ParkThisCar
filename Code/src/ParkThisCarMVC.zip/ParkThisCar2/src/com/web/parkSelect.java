/**
 * @author ibrahimmalik
 * @version 1.0
 */


package com.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.parkModule;

/**
 * @see Servlet implementation class parkSelect
 */
@WebServlet("/Park.do")
public class parkSelect extends HttpServlet implements Servlet {
	
	/**
	 * code to process the form
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*obtains coordinates INPUT lat and long, controller requests paramters from form
		 * int lat = request.getParamter("lat")
		 * int long = request.getParamter("long")
		 * 
		 * create an object of ParkModule, constructing it
		 * parkModule pm = new parkModule();
		 * list result1 = pm.park(lat);
		 * list result2 = pm.park(long);
		 * list result = pm.park(?) result that produces a list of parking spots 
		 * pm.park is an example method found in parkModule that processes the latitude and longitude
		 * 
		 * Sets results as an attribute called spaces that is passed on to result.jsp
		 * request.setAttribute("spaces",result);
		 * 
		 * This produces the result.jsp file for viewing. Attributes are passed on to result.jsp
		   	RequestDispatcher dispatcher = request.getRequestDispatcher("result.jsp");
    			dispatcher.forward(request,response);
			}
		 */
		
	}

}
